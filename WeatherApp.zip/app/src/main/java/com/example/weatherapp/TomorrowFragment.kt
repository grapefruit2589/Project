package com.example.weatherapp

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.fragment.app.Fragment

class TomorrowFragment : Fragment() {

    private lateinit var weatherTextView: TextView

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_tomorrow, container, false)
        weatherTextView = view.findViewById(R.id.weather_text_view)

        // API로 데이터 가져오기
        fetchWeatherForecast()

        return view
    }

    private fun fetchWeatherForecast() {
        // TODO: 날씨 API 호출 및 JSON 데이터 처리
        val forecast = "맑음, 22°C" // 예시 데이터
        updateWeatherView(forecast)
    }

    private fun updateWeatherView(forecast: String) {
        weatherTextView.text = "내일의 날씨: $forecast"
    }
}
