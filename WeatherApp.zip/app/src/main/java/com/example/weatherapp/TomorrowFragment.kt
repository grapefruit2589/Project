package com.example.weatherapp

import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.TextView
import androidx.fragment.app.Fragment
import org.tensorflow.lite.Interpreter
import java.nio.ByteBuffer

class TomorrowFragment : Fragment(R.layout.fragment_tomorrow) {
    private lateinit var tempModel: Interpreter
    private lateinit var rainModel: Interpreter
    private var predictedTemp: Double = 0.0
    private var rainExpected: Double = 0.0

    // TextView 객체 (레이아웃에 정의된 id와 매핑되어야 합니다)
    private lateinit var tempTextView: TextView
    private lateinit var rainTextView: TextView

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // 모델 로딩
        loadModels()

        // 예측값을 계산하여 표시
        predictTemperature() // 온도 예측
        predictRain() // 강수 예측

        // 예측된 값들을 TextView에 출력
        tempTextView = view.findViewById(R.id.tempTextView)
        rainTextView = view.findViewById(R.id.rainTextView)

        tempTextView.text = getString(R.string.predicted_temp_format, predictedTemp)
        rainTextView.text = getString(R.string.rain_expected_format, rainExpected)
    }

    // 모델 로딩 함수
    private fun loadModels() {
        try {
            // model_temp.tflite 모델 로딩
            val tempModelPath = context?.assets?.open("model_temp.tflite")?.let { inputStream ->
                val byteBuffer = ByteBuffer.allocateDirect(inputStream.available())
                inputStream.copyTo(byteBuffer) // InputStream을 ByteBuffer로 복사
                byteBuffer.rewind() // ByteBuffer의 position을 0으로 리셋
                byteBuffer
            }
            tempModel = Interpreter(tempModelPath)

            // rain_model.tflite 모델 로딩
            val rainModelPath = context?.assets?.open("rain_model.tflite")?.let { inputStream ->
                val byteBuffer = ByteBuffer.allocateDirect(inputStream.available())
                inputStream.copyTo(byteBuffer) // InputStream을 ByteBuffer로 복사
                byteBuffer.rewind() // ByteBuffer의 position을 0으로 리셋
                byteBuffer
            }
            rainModel = Interpreter(rainModelPath)
        } catch (e: Exception) {
            Log.e("TomorrowFragment", "Error loading models", e)
        }
    }

    // 온도 예측 함수
    private fun predictTemperature() {
        // 예시: 예측할 온도 데이터를 모델에 넣어서 예측된 온도를 계산
        val input = floatArrayOf(25.6f, 60.0f)  // 예시 데이터 (현재 온도, 습도 등)
        val output = FloatArray(1)  // 예측된 온도를 담을 변수

        tempModel.run(input, output)  // 모델을 사용하여 예측
        predictedTemp = output[0].toDouble()  // 예측된 온도 값 저장
    }

    // 강수 예측 함수
    private fun predictRain() {
        // 예시: 예측할 강수 확률 데이터를 모델에 넣어서 예측된 강수 확률을 계산
        val input = floatArrayOf(25.6f, 60.0f)  // 예시 데이터 (현재 온도, 습도 등)
        val output = FloatArray(1)  // 예측된 강수 확률을 담을 변수

        rainModel.run(input, output)  // 모델을 사용하여 예측
        rainExpected = output[0].toDouble()  // 예측된 강수 확률 저장
    }
}
