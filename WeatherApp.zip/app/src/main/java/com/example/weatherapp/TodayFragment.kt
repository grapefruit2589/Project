package com.example.weatherapp

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.fragment.app.Fragment

class TodayFragment : Fragment() {

    private lateinit var temperatureTextView: TextView

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_today, container, false)
        temperatureTextView = view.findViewById(R.id.temperature_text_view)

        // 데이터 가져오기
        fetchArduinoTemperature()

        return view
    }

    private fun fetchArduinoTemperature() {
        // TODO: 아두이노 센서 데이터 가져오기
        // Bluetooth 또는 Wi-Fi로 연결하여 데이터를 받아온다.
        val temperature = "25°C" // 예시 데이터
        updateTemperatureView(temperature)
    }

    private fun updateTemperatureView(temperature: String) {
        temperatureTextView.text = "현재 온도: $temperature"
    }
}
