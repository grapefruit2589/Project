package com.example.weatherapp

import android.os.Bundle
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.appcompat.app.AppCompatActivity
import java.io.IOException

class TodayFragment : Fragment(R.layout.fragment_today) {

    private lateinit var temperatureTextView: TextView
    private lateinit var bluetoothHandler: BluetoothHandler
    private val deviceAddress = "XX:XX:XX:XX:XX:XX" // 아두이노 블루투스 MAC 주소 입력

    override fun onViewCreated(view: android.view.View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // TextView 초기화
        temperatureTextView = view.findViewById(R.id.temperatureTextView)

        // Bluetooth 연결 처리
        bluetoothHandler = BluetoothHandler(deviceAddress, requireContext())

        // 권한 요청
        bluetoothHandler.requestBluetoothPermissions(requireActivity() as AppCompatActivity)

        // 연결 시도
        bluetoothHandler.connectToBluetoothDevice()

        // 데이터 읽기 및 표시
        readTemperatureData()
    }

    private fun readTemperatureData() {
        Thread {
            try {
                // Bluetooth로부터 데이터 읽기
                val data = bluetoothHandler.readData()
                if (data != null) {
                    // 아두이노에서 받은 온도 데이터를 TextView에 표시
                    requireActivity().runOnUiThread {
                        temperatureTextView.text = getString(R.string.temperature_text, data)
                    }
                }
            } catch (e: IOException) {
                requireActivity().runOnUiThread {
                    Toast.makeText(requireContext(), "온도 데이터를 읽는 중 오류 발생", Toast.LENGTH_SHORT).show()
                }
            }
        }.start()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        bluetoothHandler.disconnect() // Bluetooth 연결 해제
    }
}
