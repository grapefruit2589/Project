package com.example.weatherapp

import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private lateinit var bluetoothHandler: BluetoothHandler

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        bluetoothHandler = BluetoothHandler("device_address", this)

        // 권한 요청
        bluetoothHandler.requestBluetoothPermissions(this)

        // sendButton 클릭 시 데이터 전송
        val sendButton = findViewById<Button>(R.id.sendButton)
        sendButton.setOnClickListener {
            bluetoothHandler.sendData("Hello, Bluetooth!")
        }
    }

    // 권한 요청 결과 처리
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)

        // BluetoothHandler의 onRequestPermissionsResult 호출
        bluetoothHandler.onRequestPermissionsResult(requestCode, grantResults)
    }
}
