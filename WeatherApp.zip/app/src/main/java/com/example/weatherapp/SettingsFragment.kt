package com.example.weatherapp

import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.fragment.app.Fragment

class SettingsFragment : Fragment() {

    private lateinit var genderSpinner: Spinner
    private lateinit var styleSpinner: Spinner
    private lateinit var saveButton: Button

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_settings, container, false)

        genderSpinner = view.findViewById(R.id.spinner_gender)
        styleSpinner = view.findViewById(R.id.spinner_style)
        saveButton = view.findViewById(R.id.button_save)

        setupSpinners()
        loadPreferences()

        saveButton.setOnClickListener {
            savePreferences()
        }

        return view
    }

    private fun setupSpinners() {
        // 성별 선택 스피너 설정
        val genderOptions = arrayOf("남성", "여성")
        val genderAdapter = ArrayAdapter(
            requireContext(),
            android.R.layout.simple_spinner_item,
            genderOptions
        )
        genderAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        genderSpinner.adapter = genderAdapter

        // 스타일 선택 스피너 설정
        val styleOptions = arrayOf("캐주얼", "포멀", "스포츠", "스트릿", "빈티지")
        val styleAdapter = ArrayAdapter(
            requireContext(),
            android.R.layout.simple_spinner_item,
            styleOptions
        )
        styleAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        styleSpinner.adapter = styleAdapter
    }

    private fun loadPreferences() {
        // SharedPreferences에서 데이터 불러오기
        val sharedPreferences = requireContext().getSharedPreferences("UserPreferences", Context.MODE_PRIVATE)
        val savedGender = sharedPreferences.getInt("gender", 0) // 기본값: 0 (남성)
        val savedStyle = sharedPreferences.getInt("style", 0) // 기본값: 0 (캐주얼)

        genderSpinner.setSelection(savedGender)
        styleSpinner.setSelection(savedStyle)
    }

    private fun savePreferences() {
        // SharedPreferences에 데이터 저장
        val sharedPreferences = requireContext().getSharedPreferences("UserPreferences", Context.MODE_PRIVATE)
        val editor = sharedPreferences.edit()

        editor.putInt("gender", genderSpinner.selectedItemPosition)
        editor.putInt("style", styleSpinner.selectedItemPosition)
        editor.apply()

        Toast.makeText(requireContext(), "설정이 저장되었습니다.", Toast.LENGTH_SHORT).show()
    }
}
